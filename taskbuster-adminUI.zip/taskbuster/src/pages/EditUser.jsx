import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const EditUser = () => {
  const { userId } = useParams();
  const navigate = useNavigate();

  const confirmDelete = () => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      // Logic to delete the user
      navigate('/admin/users');
    }
  };

  const handleUpdate = () => {
    if (window.confirm('Are you sure you want to update this user?')) {
      // Logic to update the user
      alert('User updated successfully!');
    }
  };

  return (
    <div className="edit-user">
      <header>
        <button className="logo-button" onClick={() => navigate('/')}>
          LOGO
        </button>
        <div className="header-right">
          <button onClick={() => navigate('/admin/dashboard')}>Dashboard</button>
        </div>
      </header>
      <div className="user-details-container">
        <button className="back-button" onClick={() => navigate('/admin/users')}>
          {'< Back'}
        </button>
        <h2>Edit User</h2>
        <div className="user-details">
          <label>
            Name:
            <input type="text" defaultValue="John Doe" />
          </label>
          <label>
            Date Joined:
            <input type="date" defaultValue="2023-01-01" />
          </label>
          <label>
            Privileges:
            <select defaultValue="Editor">
              <option value="Admin">Admin</option>
              <option value="Editor">Editor</option>
              <option value="Viewer">Viewer</option>
            </select>
          </label>
          <div className="actions">
            <button
              style={{ backgroundColor: '#fdcc01' }}
              onClick={handleUpdate}
            >
              Save Changes
            </button>
            <button
              style={{ backgroundColor: 'red', color: 'white' }}
              onClick={confirmDelete}
            >
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditUser;
