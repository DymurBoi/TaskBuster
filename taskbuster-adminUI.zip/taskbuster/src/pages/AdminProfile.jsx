import React from 'react';
import { useNavigate } from 'react-router-dom';

const AdminProfile = () => {
  const navigate = useNavigate();

  const confirmDelete = () => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      // Delete account logic
    }
  };

  return (
    <div className="admin-profile">
      <header>
        <button className="logo-button" onClick={() => navigate('/')}>LOGO</button>
        <div className="header-right">
          <button onClick={() => navigate('/login')}>Log In</button>
          <button onClick={() => navigate('/signup')}>Sign up</button>
        </div>
      </header>

      <button className="back-button" onClick={() => navigate('/admin/dashboard')}>&lt; Back</button>
      <br></br>

      <div className="name-date-container">
        <div className="profile-text">
          <strong>Name:</strong> Admin Name {/* Replace 'Admin Name' dynamically with backend data */}
        </div>
        <br></br>
        <div className="profile-text">
          <strong>Date Joined:</strong> 01/01/2023 {/* Replace date dynamically with backend data */}
        </div>
      </div>
      <br></br>
      <button className="delete-account-button" onClick={confirmDelete}>Delete Account</button>
      <br></br>
      <div className="privileges-box">
        <strong>Privileges:</strong>
        <p className="privileges-text">
          Full Access, User Management, etc. {/* Replace privileges dynamically with backend data */}
        </p>
      </div>
      <br></br>
      <div className="profile-actions">
        <button onClick={() => {/* Edit profile logic */}} className="edit-profile-button">Edit Profile</button>
        <button onClick={() => navigate('/logout')} className="logout-button">Log Out</button>
      </div>
    </div>
  );
};

export default AdminProfile;
