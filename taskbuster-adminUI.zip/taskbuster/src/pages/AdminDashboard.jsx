// src/pages/AdminDashboard.jsx

import React from 'react';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="admin-dashboard">
      <header>
        <button className="logo-button" onClick={() => navigate('/')}>LOGO</button>
        <div className="header-right">
          <button onClick={() => navigate('/login')}>Log In</button>
          <button onClick={() => navigate('/signup')}>Sign up</button>
        </div>
      </header>
      <div className="dashboard-content">
        <h2>Dashboard</h2>
        <p>Welcome to the admin dashboard!</p>
        {/* Add more dashboard contents here as needed */}
      </div>
    </div>
  );
};

export default AdminDashboard;
