import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';

const AdminLoginPage = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const togglePasswordVisibility = () => setShowPassword(!showPassword);

  const handleLogin = () => {
    // Placeholder for authentication logic
    navigate('/admin/dashboard');
  };

  return (
    <div className="admin-login">
      <header>
        <button className="logo-button" onClick={() => navigate('/')}>LOGO</button>
        <div className="header-right">
          <button onClick={() => navigate('/login')}>Log In</button>
          <button onClick={() => navigate('/signup')}>Sign up</button>
        </div>
      </header>
      <div className="login-form">
        <input type="email" placeholder="Email" required />
        <div className="password-field">
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <FontAwesomeIcon
            icon={showPassword ? faEyeSlash : faEye}
            onClick={togglePasswordVisibility}
            className="eye-icon"
          />
        </div>
        <button onClick={handleLogin}>Log In</button>
      </div>
    </div>
  );
};

export default AdminLoginPage;
