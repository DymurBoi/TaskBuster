import React from 'react';
import { useNavigate } from 'react-router-dom';

const AdminUsers = () => {
  const navigate = useNavigate();

  const users = [
    { id: 1, name: 'John Doe', dateJoined: '2023-01-01', privileges: 'Editor' },
    { id: 2, name: 'Jane Smith', dateJoined: '2023-02-15', privileges: 'Viewer' },
    { id: 3, name: 'Mike Johnson', dateJoined: '2023-03-10', privileges: 'Admin' },
  ];

  return (
    <div className="admin-users">
      <header>
        <button className="logo-button" onClick={() => navigate('/')}>
          LOGO
        </button>
        <div className="header-right">
          <button onClick={() => navigate('/admin/dashboard')}>Dashboard</button>
        </div>
      </header>
      <div className="users-container">
        <h1>Manage Users</h1>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Date Joined</th>
              <th>Privileges</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.dateJoined}</td>
                <td>{user.privileges}</td>
                <td>
                  <button
                    onClick={() => navigate(`/admin/users/${user.id}`)}
                  >
                    Edit
                  </button>
                  <button
                    style={{ backgroundColor: 'red', color: 'white' }}
                    onClick={() =>
                      window.confirm('Are you sure you want to delete this user?')
                    }
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminUsers;
